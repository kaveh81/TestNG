package test.first;

import java.rmi.Remote;

public interface RemoteInterface extends Remote {

}
