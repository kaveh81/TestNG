The files in this directory should not be modified directly.

Instead the files in the javancss directory at the root of the cobertura project should be modified.

See the coberturaREADME.txt file located in that directory.