select ashexewkb(the_geom, 'NDR') from loadedshp;
select ashexewkb(the_geom, 'XDR') from loadedshp;
select asewkt(the_geom) from loadedshp;
